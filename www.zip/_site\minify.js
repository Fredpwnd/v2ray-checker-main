const fs = require('fs');
const path = require('path');
const CleanCSS = require('clean-css');

const cssFiles = [
  '_includes/css/base.css',
  '_includes/css/main.css',
  '_includes/css/skeleton.css'
];

try {
  cssFiles.forEach(file => {
    const input = fs.readFileSync(file, 'utf8');
    const output = new CleanCSS({}).minify(input).styles;
    const outputPath = file.replace('.css', '.min.css');
    fs.writeFileSync(outputPath, output);
    console.log(`Minified ${file} -> ${outputPath}`);
  });
} catch (error) {
  console.error('Error minifying CSS:', error);
}const fs = require('fs');
const path = require('path');
const CleanCSS = require('clean-css');

const cssFiles = [
  '_includes/css/base.css',
  '_includes/css/main.css',
  '_includes/css/skeleton.css'
];

cssFiles.forEach(file => {
  const input = fs.readFileSync(file, 'utf8');
  const output = new CleanCSS({}).minify(input).styles;
  const outputPath = file.replace('.css', '.min.css');
  fs.writeFileSync(outputPath, output);
  console.log(`Minified ${file} -> ${outputPath}`);
});
